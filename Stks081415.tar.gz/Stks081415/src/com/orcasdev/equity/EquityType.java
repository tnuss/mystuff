package com.orcasdev.equity;

public enum EquityType {

	STOCK, INDEX
	
}
