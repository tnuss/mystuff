package com.orcasdev.equity;

public enum StorageType {
	FILE_TXT, FILE_XML, DB
}
