package com.orcasdev.service;


/**
 * Purpose:
 * 1) Take a DayDataList of equities and write out files for each member of list
 *  Will need a file formatt, where to store, and FileIOSevice
 *  
 * @author tnuss
 *
 */
public class DayDataStore {

}
