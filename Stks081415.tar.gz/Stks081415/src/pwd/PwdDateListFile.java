package pwd;

import infra.ItemFileSuper;
import infra.ItemListIF;

import java.util.ArrayList;

public class PwdDateListFile extends ItemFileSuper implements ItemListIF<PWordAndDate> {

 
    public void saveItemList(ArrayList<PWordAndDate> iList) throws Exception {
        // TODO Auto-generated method stub
        
    }

    public void saveItemList() throws Exception {
        // TODO Auto-generated method stub
        
    }

    public ArrayList<PWordAndDate> loadItemList() {
        // TODO Auto-generated method stub
        return null;
    }

}
