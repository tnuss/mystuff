package mypackage.hello;

public class TestHello {

	static final String varHello = "Hello class says: Hello!";
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	
	public String getResponse() {
		return varHello;
	}

}
